<div class="wrap">
    <div class="row">
        <div class="col-xs-12">
            
			<div class="row awr-advertise" >
            	<div class="col-xs-12 col-md-6">
                    <strong>  <a target="_blank" href="http://codecanyon.net/item/woocommerce-tabs-pro-extra-tabs-for-product-page/8218941">Woocommerce Tabs Pro: Extra Tabs for Product Page </a> </strong>
	                <a target="_blank" href="http://codecanyon.net/item/woocommerce-tabs-pro-extra-tabs-for-product-page/8218941"><img src="https://0.s3.envato.com/files/113914698/main.jpg"></a>
                </div>
                <div class="col-xs-12 col-md-6">
                    <strong> <a target="_blank" href="http://codecanyon.net/item/mega-search-advanced-live-ajax-search-plugin/12504044?ref=proword">Mega Search : Advanced Live Ajax Search Plugin</a>  </strong>
                    <a target="_blank" href="http://codecanyon.net/item/mega-search-advanced-live-ajax-search-plugin/12504044?ref=proword"><img src="https://image-cc.s3.envato.com/files/145635791/Search_Banner.jpg"></a>
                </div>
                
                <div class="col-xs-12 col-md-12">
                    <strong> <a target="_blank" href="http://codecanyon.net/item/woocommerce-brands/8039481"> WooCommerce Brands </a></strong>
                	<a target="_blank" href="http://codecanyon.net/item/woocommerce-brands/8039481"><img src="https://0.s3.envato.com/files/111203951/Brand_display.jpg"></a>
                </div>
                <div class="col-xs-12 col-md-6">
                    <strong> <a target="_blank" href="http://codecanyon.net/item/advance-post-gridlist-with-custom-filtering-for-visual-composer/8712997"> Advance Post Grid/List with custom filtering for Visual Composer </a></strong>
	                <a target="_blank" href="http://codecanyon.net/item/advance-post-gridlist-with-custom-filtering-for-visual-composer/8712997"><img src="https://0.s3.envato.com/files/115930813/banner_grid.jpg"></a>
                 </div>
                <div class="col-xs-12 col-md-6">
                	<strong> <a target="_blank" href="http://codecanyon.net/item/post-layout-box-style-for-visual-composer/8531656">Post Layout : Box Style for Visual Composer</a> </strong>
                	<a target="_blank" href="http://codecanyon.net/item/post-layout-box-style-for-visual-composer/8531656"><img src="https://0.s3.envato.com/files/104643187/banner_box.jpg"></a>
                </div>
                <div class="col-xs-12 col-md-6">
                    <strong> <a target="_blank" href="http://codecanyon.net/item/post-layout-carousel-slider-for-visual-composer/8586588">Post Layout: Carousel + Slider for Visual Composer</a>  </strong>
                	<a target="_blank" href="http://codecanyon.net/item/post-layout-carousel-slider-for-visual-composer/8586588"><img src="https://0.s3.envato.com/files/104641627/banner_slide.jpg"></a>
                </div>
                <div class="col-xs-12 col-md-6">
                    <strong>  <a  target="_blank" href="http://codecanyon.net/item/post-layout-news-ticker-for-visual-composer/8535779"> Post Layout : News Ticker for Visual Composer </a>  </strong>
                	<a  target="_blank" href="http://codecanyon.net/item/post-layout-news-ticker-for-visual-composer/8535779"><img src="https://0.s3.envato.com/files/100661404/banner.jpg"></a>
                 </div>   
                <div class="col-xs-12 col-md-12">
                    <strong> <a target="_blank" href="http://codecanyon.net/item/advanced-woocommerce-reporting-/12042129?ref=proword">Advanced WooCommerce Reporting </a> </strong>
                    <a target="_blank" href="http://codecanyon.net/item/advanced-woocommerce-reporting-/12042129?ref=proword"><img src="https://image-cc.s3.envato.com/files/140519274/woo_reporting_BANNER.jpg"></a>
                </div>
                
                <div class="col-xs-12 col-md-6">
                    <strong><a target="_blank" href="http://codecanyon.net/item/woo-sale-revolutionflash-saledynamic-discounts/9855119?WT.ac=item_more_thumb&WT.z_author=proword">  Woo Sale Revolution:Flash Sale+Dynamic Discounts </a></strong>
               	 	<a target="_blank" href="http://codecanyon.net/item/woo-sale-revolutionflash-saledynamic-discounts/9855119?WT.ac=item_more_thumb&WT.z_author=proword"><img src="https://0.s3.envato.com/files/115934601/banner.jpg"></a>
               	</div>
                <div class="col-xs-12 col-md-6">
                    <strong><a target="_blank" href="http://codecanyon.net/item/wp-progrid-ajax-postcustom-posts-displayfilter/10457623?ref=proword">  WP ProGrid: Ajax Post/Custom Posts Display+Filter</a> </strong>
                    <a target="_blank" href="http://codecanyon.net/item/wp-progrid-ajax-postcustom-posts-displayfilter/10457623?ref=proword"><img src="https://0.s3.envato.com/files/122901631/Banner_final.jpg"></a>
                </div>
                 <div class="col-xs-12 col-md-12">
                    <strong><a target="_blank" href="http://codecanyon.net/item/magic-gridwoocommerce-display-productajax-filter/9936306?WT.ac=follow&WT.z_author=proword"> Magic Grid:WooCommerce Display Product+Ajax Filter</a> </strong>
                    <a target="_blank" href="http://codecanyon.net/item/magic-gridwoocommerce-display-productajax-filter/9936306?WT.ac=follow&WT.z_author=proword"><img src="https://0.s3.envato.com/files/117239829/woogrid_banner.jpg"></a>
               	</div>
                <div class="col-xs-12 col-md-6">
                	<strong> <a target="_blank" href="http://codecanyon.net/item/woo-gift-advanced-woocommerce-gift-plugin/10685086?ref=proword">  Woo Gift : Advanced Woocommerce Gift Plugin </a> </strong>
                	<a target="_blank" href="http://codecanyon.net/item/woo-gift-advanced-woocommerce-gift-plugin/10685086?ref=proword"><img src="https://0.s3.envato.com/files/125407856/MAIN.jpg"></a>
                </div>
                <div class="col-xs-12 col-md-6">
	                <strong> <a target="_blank" href="http://codecanyon.net/item/vip-shop-advanced-woocommerce-vip-plugin/11125379?ref=proword"> VIP Shop : Advanced WooCommerce VIP Plugin </a></strong>
                	<a target="_blank" href="http://codecanyon.net/item/vip-shop-advanced-woocommerce-vip-plugin/11125379?ref=proword"><img src="https://0.s3.envato.com/files/130064882/Vip_banner.jpg"></a>
                </div>
                <div class="col-xs-12 col-md-6">
                    <strong> <a target="_blank" href="http://codecanyon.net/item/unique-slider-visual-composer-perspective-slider/11454239?ref=proword">  Unique Slider :Visual Composer Perspective Slider </a></strong>
                    <a target="_blank" href="http://codecanyon.net/item/unique-slider-visual-composer-perspective-slider/11454239?ref=proword"><img src="https://0.s3.envato.com/files/133964420/banner_unique.jpg"></a>
                </div>
                
                <div class="col-xs-12 col-md-6">
                    <strong> <a target="_blank" href="http://codecanyon.net/item/woocommerce-cash-back-credit-reward-program/9594808?WT.ac=item_more_thumb&WT.z_author=proword"> WooCommerce Cash Back & Credit Reward Program </a></strong>
                	<a target="_blank" href="http://codecanyon.net/item/woocommerce-cash-back-credit-reward-program/9594808?WT.ac=item_more_thumb&WT.z_author=proword"><img src="https://0.s3.envato.com/files/116633906/banner.png"></a>
               	</div>
                <div class="col-xs-12 col-md-6">
                    <strong> <a target="_blank" href="http://codecanyon.net/item/customer-club-advanced-woocommerce-point-system/9381044?WT.ac=item_more_thumb&WT.z_author=proword"> Customer Club: Advanced WooCommerce Point System </a></strong>
                	<a target="_blank" href="http://codecanyon.net/item/customer-club-advanced-woocommerce-point-system/9381044?WT.ac=item_more_thumb&WT.z_author=proword"><img src="https://0.s3.envato.com/files/117071313/banner.jpg"></a>
                </div>
                 <div class="col-xs-12 col-md-6">
                    <strong><a target="_blank" href="http://codecanyon.net/item/accordion-slider-for-visual-composer/12618586?ref=proword">Accordion Slider for Visual Composer </a> </strong>
                    <a target="_blank" href="http://codecanyon.net/item/accordion-slider-for-visual-composer/12618586?ref=proword"><img src="https://image-cc.s3.envato.com/files/146514666/VC_Accordion_Banner.jpg"></a>
                </div>	
                
        	</div>            
        
        </div><!--col-xs-12 -->
    </div><!--row -->
</div><!--wrap -->
