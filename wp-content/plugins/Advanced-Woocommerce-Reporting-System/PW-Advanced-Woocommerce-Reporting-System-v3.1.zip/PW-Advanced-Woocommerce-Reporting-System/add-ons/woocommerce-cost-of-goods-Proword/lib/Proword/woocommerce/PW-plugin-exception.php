<?php


defined( 'ABSPATH' ) or exit;

if ( ! class_exists( 'PW_COST_GOOD_ASSIST_EXCEPTION' ) ) :

	/**
	 * Plugin Framework Exception - generic Exception
	 */
	class PW_COST_GOOD_ASSIST_EXCEPTION extends Exception { }

endif;  // class exists check
