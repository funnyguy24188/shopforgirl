<?php


defined( 'ABSPATH' ) or exit;

if ( ! class_exists( 'PW_COST_GOOD_ASSIST_API' ) ) :

	/**
	 * Plugin Framework API Exception - generic API Exception
	 */
	class PW_COST_GOOD_ASSIST_API extends PW_COST_GOOD_ASSIST_EXCEPTION { }

endif;  // class exists check
